
import java.util.Scanner;
public class Payroll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of employees:\t");
		int n=sc.nextInt();
		
		Employee arr[]=new Employee[n];
		
		String Name="";
		int Skill=0;
		double hours=0.0;
		int hpr=0;
		double netpay=0.0;//total net salary paid by Company		
		for(int i=0;i<n;i++)
		{
			int m=0,d=0,l=0;
			double rpay=0.0;
			double opay=0.0;
			double tpay=0.0;
			double damnt=0.0;
			double npay=0.0;
			hours=0;
			
			System.out.print("Enter Name:\t");
			Name=sc.next();
			
			System.out.print("Enter Skill Level:\t");
			Skill=sc.nextInt();
			
			if(Skill==1)
				hpr=170;
			
			if(Skill==2)
				hpr=200;
			
			if(Skill==3)
				hpr=450;
			
			
			System.out.print("Enter hours worked:\t");
			hours=sc.nextDouble();
			
			if(Skill==2|| Skill==3)
			{	System.out.println("Enter 1 for YES and 0 for NO");
				System.out.print("Medical Insuarance:\t");
				m=sc.nextInt();
				
				
				System.out.print("Dental Insuarance:\t");
				d=sc.nextInt();
				
				System.out.print("Long-Term Insuarance:\t");
				l=sc.nextInt();
				System.out.println();
			}
			
			if(hours>40)
			{
				rpay=1*hpr*40;
				opay=1.5*hpr*(hours-40);
				tpay=rpay+opay;
				damnt=m*32.50+d*20+l*10;
				npay=tpay-damnt;
			}
			else
			{
				rpay=1*hpr*hours;
				tpay=rpay+opay;
				damnt=m*32.50+d*20+l*10;
				npay=tpay-damnt;
			}
			
			
			netpay+=npay;
			arr[i]=new Employee(Name,Skill,hours,hpr,m,d,l,rpay,opay,tpay,damnt,npay);
			
		}
		for(int i=0;i<n;i++)
		{
			//System.out.println("Name\t\tHours\tPerhour\tRegular Pay\tOver Pay\tTotal Pay\tDeduction\tNet Pay");
			arr[i].toPrint();
			if(i==n-1)
				System.out.println("Net Salary paid by Company:		"+netpay);
		}
			
			
		}

	}


