At first enter the number of employees in the company
then keep on entering the details of each employee one by one
At last it display the Payroll data of each employee in a table form
The first column represent the name of the employee
Second column represent the Perhour rate
Third column represent the Regular Pay amount
Fourth column represent the OverTime Pay
Fifth column represnt the Total Payement
Sixth column represent the Deduction Amount
Seventh column represent the Net Amount

last line of the output is the net salary paid by the company to all of its employees