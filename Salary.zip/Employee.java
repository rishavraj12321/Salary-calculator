
public class Employee {
	String Name="";//Name
	int  Skill=0;//Skill
	double hw=0;//Number of hours worked
	int m,d,l=0;//m,d and l corresponds to medical,dental and long-term insuarance
	int hpr=0;//hour rate
	double rpay=0.0;//regular pay
	double opay=0.0;//overtime pay
	double tpay=0.0;//total pay
	double damnt=0.0;//deduction amount
	double npay=0.0;//netpay after deduction amount
	public Employee(String Name,int Skill,double hw,int hpr,int m,int d,int l,double rpay,double opay,double tpay,double damnt,double npay)
	{
		this.Name=Name;
		this.Skill=Skill;
		this.hw=hw;
		this.hpr=hpr;
		this.m=m;
		this.d=d;
		this.l=l;
		this.rpay=rpay;
		this.opay=opay;
		this.tpay=tpay;
		this.damnt=damnt;
		this.npay=npay;
	}
	
	public void toPrint()//method to print the details of an employee
	{
		if(npay>=0)
		System.out.println(Name+"\t\t"+hw+"\t"+hpr+"\t"+rpay+"\t"+opay+"\t"+tpay+"\t"+damnt+"\t"+npay);
		else
		System.out.println(Name+"\t"+"Error:Net Pay turns out to be Negative");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

